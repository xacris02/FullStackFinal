package com.example.registrarcita.model;

public enum Role {
    ROLE_USER,
    ROLE_ADMIN
}
