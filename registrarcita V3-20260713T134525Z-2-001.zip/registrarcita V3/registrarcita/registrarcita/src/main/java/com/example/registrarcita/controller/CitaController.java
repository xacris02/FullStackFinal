package com.example.registrarcita.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.registrarcita.client.ClienteClient;
import com.example.registrarcita.dto.ClienteDTO;
import com.example.registrarcita.model.Cita;
import com.example.registrarcita.service.CitaService;
import io.swagger.v3.oas.annotations.Parameter;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("/api/v1/citas")
public class CitaController {

    @Autowired
    private CitaService citaService;

    @Autowired
    private ClienteClient clienteClient;

    @PostMapping
    public ResponseEntity<?> registrar(
        @RequestBody Cita cita, 
        @Parameter(hidden = true) @RequestHeader("Authorization") String token) {
        
        try {
            // 1. Ahora recibimos un objeto ClienteDTO desde la otra API
            ClienteDTO clienteRespuesta = clienteClient.obtenerCliente(cita.getClienteId(), token);
            
            // 2. Validamos si el objeto vino nulo
            if (clienteRespuesta == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body("Error: El cliente con ID " + cita.getClienteId() + " no existe. La cita fue cancelada.");
            }

            System.out.println("Validación exitosa, paciente encontrado: " + clienteRespuesta.getNombre());

            Cita nuevaCita = citaService.registrar(cita);
            return ResponseEntity.status(HttpStatus.CREATED).body(nuevaCita);
            
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error al registrar la cita: " + e.getMessage());
        }
    }

    @GetMapping
    public List<Cita> listar() {
        return citaService.listarTodo();
    }

    @GetMapping("/{id}")
    public EntityModel<Cita> buscarPorId(@PathVariable int id) { 
        
        // 1. Buscamos la cita normal en tu servicio
        Cita cita = citaService.obtenerPorId(id);

        // 2. Construimos el Link
        WebMvcLinkBuilder link = linkTo(methodOn(this.getClass()).buscarPorId(id));

        // 3. Envolvemos la cita y le inyectamos el link
        return EntityModel.of(cita, link.withSelfRel());
    }

    @PutMapping("/{id}")
    public Cita actualizar(@PathVariable int id, @RequestBody Cita cita) {
        cita.setIdCita(id); // 4. Asignamos el ID a la cita
        return citaService.editar(cita);
    }

    @DeleteMapping("/{id}")
    public String eliminar(@PathVariable int id) {
        boolean eliminado = citaService.borrar(id);
        if (eliminado) {
            // 5. Actualizamos los mensajes de respuesta
            return "La cita con ID " + id + " fue eliminada exitosamente.";
        } else {
            return "No se encontró la cita con ID " + id;
        }
    }

    // =========================================================
    // NUEVO MÉTODO (PASO 3): TRAER CITA CON DETALLES DEL CLIENTE
    // =========================================================
    @GetMapping("/completa/{id}")
    public ResponseEntity<?> obtenerCitaConDetalles(
            @PathVariable int id, 
            @RequestHeader("Authorization") String token) {
        
        try {
            // 1. Buscamos la cita en nuestra base de datos (db_citas)
            Cita cita = citaService.obtenerPorId(id);
            if (cita == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Cita no encontrada.");
            }

            // 2. Usamos Feign para traer los datos del cliente desde la otra API
            ClienteDTO cliente = clienteClient.obtenerCliente(cita.getClienteId(), token);

            // 3. Armamos un paquete con ambas piezas de información
            Map<String, Object> respuesta = new HashMap<>();
            respuesta.put("citaInfo", cita);
            respuesta.put("pacienteInfo", cliente);

            return ResponseEntity.ok(respuesta);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error al traer los datos combinados: " + e.getMessage());
        }
    }
}