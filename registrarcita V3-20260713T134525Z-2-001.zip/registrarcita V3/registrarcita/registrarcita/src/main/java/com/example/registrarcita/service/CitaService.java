package com.example.registrarcita.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.registrarcita.model.Cita;
import com.example.registrarcita.repository.CitaRepository; // Importación corregida

@Service
public class CitaService { // Nombre de la clase corregido

    @Autowired
    private CitaRepository citaRepository; // Variable corregida

    public Cita registrar(Cita cita) { // Parámetro corregido
        return citaRepository.save(cita);
    }

    public List<Cita> listarTodo() {
        return citaRepository.findAll();
    }

    public Cita obtenerPorId(int id) {
        return citaRepository.findById(id).orElse(null);
    }

    public Cita editar(Cita cita) { // Parámetro corregido
        return citaRepository.save(cita);
    }

    public boolean borrar(int id) {
        if (citaRepository.existsById(id)) {
            citaRepository.deleteById(id);
            return true;
        }
        return false;
    }

    public List<Cita> registrarMasivo(List<Cita> citas) { // Parámetro corregido
        return citaRepository.saveAll(citas);
    }
}