package com.example.registrarcita.dto;

// Usamos esta clase solo para "atrapar" los datos que nos manda la otra API
public class ClienteDTO {
    private int id;
    private String nombre;
    private String correo;
    private String telefono;

    // Genera aquí los Getters y Setters (o ponle @Data arriba si usas Lombok)
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }
    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }
}