package com.example.registrarcita.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.registrarcita.model.Cita;

@Repository
public interface CitaRepository extends JpaRepository<Cita, Integer> {

}