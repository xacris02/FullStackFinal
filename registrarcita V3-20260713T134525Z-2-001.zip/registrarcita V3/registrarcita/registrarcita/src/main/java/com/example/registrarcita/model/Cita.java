package com.example.registrarcita.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data
public class Cita {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_cta") // <--- Esto le dice a Spring que en la DB se llama 'id'
    private Integer idCita;

    private String fecha;
    private String especialidad;

    @Column(name = "cliente_id") // <--- En la DB es cliente_id, no clienteId
    private Integer clienteId;
}