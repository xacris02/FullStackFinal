package com.example.registrarcita;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.example.registrarcita.model.Role;
import com.example.registrarcita.model.User;
import com.example.registrarcita.repository.UserRepository;

@SpringBootApplication
@EnableFeignClients // La antena para comunicarse con la otra API
public class RegistrarcitaApplication {

    public static void main(String[] args) {
        SpringApplication.run(RegistrarcitaApplication.class, args);
    }

    // Tu generador automático de usuarios
    @Bean
    CommandLineRunner init(UserRepository repo, PasswordEncoder encoder) {
        return args -> {
            if (repo.findByUsername("admin").isEmpty()) {
                User user = new User();
                user.setUsername("admin");
                user.setPassword(encoder.encode("1234"));
                user.setRole(Role.ROLE_ADMIN);
                repo.save(user);
            }
        };
    }
}