package com.example.registrarcita.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;

import com.example.registrarcita.dto.ClienteDTO; // Importamos el molde

@FeignClient(name = "cliente-service", url = "http://localhost:8080")
public interface ClienteClient {

    @GetMapping("/api/v4/clientes/{id}") 
    ClienteDTO obtenerCliente(
            @PathVariable("id") Integer id, 
            @RequestHeader("Authorization") String token
    );
}