package com.example.registrarcita.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.registrarcita.model.Cita;
import com.example.registrarcita.repository.CitaRepository; // Asegúrate de que el nombre coincida

@ExtendWith(MockitoExtension.class)
public class CitaServiceTest {

    // 1. El "clon" de la base de datos de citas
    @Mock
    private CitaRepository citaRepository;

    // 2. Tu servicio real que vamos a probar
    @InjectMocks
    private CitaService citaService;

    @Test
    public void testObtenerPorId() {
        // --- PREPARAR EL ESCENARIO ---
        Cita citaFalsa = new Cita();
        citaFalsa.setIdCita(1);
        citaFalsa.setEspecialidad("Cardiología");
        citaFalsa.setClienteId(5); // Simulamos que pertenece al cliente 5

        // Le decimos al clon qué responder
        when(citaRepository.findById(1)).thenReturn(Optional.of(citaFalsa));

        // --- EJECUTAR LA ACCIÓN ---
        Cita resultado = citaService.obtenerPorId(1);

        // --- VERIFICAR RESULTADOS ---
        assertNotNull(resultado, "La cita no debería ser nula");
        assertEquals("Cardiología", resultado.getEspecialidad(), "La especialidad no coincide");
        
        // Verificamos que se consultó a la base de datos 1 vez
        verify(citaRepository, times(1)).findById(1);
    }
}