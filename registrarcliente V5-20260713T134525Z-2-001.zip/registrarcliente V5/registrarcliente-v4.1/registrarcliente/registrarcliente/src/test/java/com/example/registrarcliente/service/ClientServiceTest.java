package com.example.registrarcliente.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.registrarcliente.model.Cliente;
import com.example.registrarcliente.repository.ClienteRepository;

// Le decimos a Spring que usaremos Mockito (el creador de clones)
@ExtendWith(MockitoExtension.class)
public class ClientServiceTest {

    // 1. Creamos un "clon" falso del repositorio (para NO tocar la DB real)
    @Mock
    private ClienteRepository clienteRepository;

    // 2. Inyectamos ese clon falso dentro de tu servicio real
    @InjectMocks
    private ClienteService clienteService;

    @Test
    public void testObtenerPorId() {
        // --- FASE 1: ARRANGE (PREPARAR EL ESCENARIO) ---
        // Creamos un cliente falso de utilería
        Cliente clienteFalso = new Cliente();
        clienteFalso.setId(1);
        clienteFalso.setNombre("Marcelo Test");
        clienteFalso.setCorreo("marcelo@test.com");

        // Le enseñamos al clon cómo debe responder: "Si alguien busca el ID 1, devuelve el clienteFalso"
        when(clienteRepository.findById(1)).thenReturn(Optional.of(clienteFalso));

        // --- FASE 2: ACT (EJECUTAR LA ACCIÓN) ---
        // Llamamos al método real de tu servicio
        Cliente resultado = clienteService.obtenerPorId(1);

        // --- FASE 3: ASSERT (VERIFICAR RESULTADOS) ---
        // Comprobamos que el resultado no sea nulo
        assertNotNull(resultado, "El cliente no debería ser nulo");
        // Comprobamos que el nombre coincida
        assertEquals("Marcelo Test", resultado.getNombre(), "El nombre del cliente no coincide");
        
        // Verificamos que el servicio efectivamente llamó a la base de datos exactamente 1 vez
        verify(clienteRepository, times(1)).findById(1);
    }
}