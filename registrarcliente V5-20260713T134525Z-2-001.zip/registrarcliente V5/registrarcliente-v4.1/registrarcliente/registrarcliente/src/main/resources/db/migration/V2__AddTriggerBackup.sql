CREATE TRIGGER despues_insert_cliente
AFTER INSERT ON clientes
FOR EACH ROW
INSERT INTO clientes_backup (id, nombre, correo, telefono, fecha_backup)
VALUES (NEW.id, NEW.nombre, NEW.correo, NEW.telefono, NOW());