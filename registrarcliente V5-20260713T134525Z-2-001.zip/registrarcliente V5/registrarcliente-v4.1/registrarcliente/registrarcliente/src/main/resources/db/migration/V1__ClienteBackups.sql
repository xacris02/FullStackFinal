CREATE TABLE IF NOT EXISTS clientes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(255),
    correo VARCHAR(255),
    telefono VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS clientes_backup (
    id_backup INT AUTO_INCREMENT PRIMARY KEY,
    id INT,
    nombre VARCHAR(255),
    correo VARCHAR(255),
    telefono VARCHAR(255),
    fecha_backup DATETIME
);

-- ESTA ES LA TABLA QUE FALTABA PARA TU SEGURIDAD JWT
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) UNIQUE,
    password VARCHAR(255),
    role VARCHAR(50)
);