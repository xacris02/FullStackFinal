package com.example.registrarcliente.controller;

import com.example.registrarcliente.model.Cliente;
import com.example.registrarcliente.service.ClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("/api/v4/clientes")
@Tag(name = "Clientes", description = "Operaciones relacionadas con los clientes") // Nombre en Swagger
public class ClientController { 
    @Autowired
    private ClienteService clienteService;

    @Operation(summary = "Crear un nuevo cliente", description = "Guarda un cliente en la base de datos (Requiere Token)")
    @PostMapping
    public Cliente registrar(@RequestBody Cliente cliente) {
        return clienteService.registrar(cliente);
    }

    @GetMapping
    public List<Cliente> listar() {
        return clienteService.listarTodo();
    }

    @GetMapping("/{id}")
    public EntityModel<Cliente> buscarPorId(@PathVariable int id) { 
        
        // 1. Buscamos el cliente normal en tu servicio
        Cliente cliente = clienteService.obtenerPorId(id);

        // 2. Construimos el Link que apunta a este mismo método (self)
        WebMvcLinkBuilder link = linkTo(methodOn(this.getClass()).buscarPorId(id));

        // 3. Envolvemos al cliente y le inyectamos el link
        return EntityModel.of(cliente, link.withSelfRel());
    }

    @PutMapping("/{id}")
    public Cliente actualizar(@PathVariable int id, @RequestBody Cliente cliente) {
        cliente.setId(id);
        return clienteService.editar(cliente);
    }

    @DeleteMapping("/{id}")
    public String eliminar(@PathVariable int id) {
        boolean eliminado = clienteService.borrar(id);
        if (eliminado) {
            return "Cliente con ID " + id + " fue eliminado.";
        } else {
            return "No se encontró el cliente con ID " + id;
        }
    }

    @PostMapping("/masivo")
    public List<Cliente> registrarMasivo(@RequestBody List<Cliente> clientes) {
        return clienteService.registrarMasivo(clientes);
    }

}