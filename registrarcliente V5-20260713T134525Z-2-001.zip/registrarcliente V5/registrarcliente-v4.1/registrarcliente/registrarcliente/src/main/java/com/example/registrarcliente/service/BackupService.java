package com.example.registrarcliente.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import jakarta.annotation.PostConstruct;
import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Service
public class BackupService {

    @Value("${spring.datasource.username}")
    private String dbUser;

    @Value("${spring.datasource.password}")
    private String dbPass;

    @Value("${backup.path}")
    private String backupPath;

    @PostConstruct
    public void createBackup() {
        try {
            File directory = new File(backupPath);
            if (!directory.exists()) directory.mkdirs();

            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmm"));
            String fullPath = backupPath + "backup_" + timestamp + ".sql";

            String exePath = "C:\\laragon\\bin\\mysql\\mysql-8.4.3-winx64\\bin\\mysqldump.exe";

            String userParam = dbUser.trim();
            String passParam = dbPass.trim();

            ProcessBuilder pb = new ProcessBuilder(
                exePath,
                "-u", userParam,
                "-p" + passParam, 
                "-h", "127.0.0.1",
                "-P", "3309",
                "--skip-opt",
                "--quick",
                "db_clientes",
                "--result-file=" + fullPath
            );
            Process process = pb.start();
            int exitCode = process.waitFor();

            if (exitCode == 0) {
                System.out.println("Backup generado: " + fullPath);
            } else {
                System.err.println("Falló el backup. Código: " + exitCode);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}