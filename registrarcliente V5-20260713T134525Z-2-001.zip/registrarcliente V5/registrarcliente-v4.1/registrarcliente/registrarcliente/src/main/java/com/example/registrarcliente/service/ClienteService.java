package com.example.registrarcliente.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.registrarcliente.model.Cliente;
import com.example.registrarcliente.repository.ClienteRepository;

@Service
public class ClienteService {

    @Autowired
    private ClienteRepository clienteRepository;

    public Cliente registrar(Cliente cliente) {

        return clienteRepository.save(cliente);
    }

    public List<Cliente> listarTodo() {
        return clienteRepository.findAll();
    }

    public Cliente obtenerPorId(int id) {
        return clienteRepository.findById(id).orElse(null);
    }

    public Cliente editar(Cliente cliente) {

        return clienteRepository.save(cliente);
    }

    public boolean borrar(int id) {
        if (clienteRepository.existsById(id)) {
            clienteRepository.deleteById(id);
            return true;
        }
        return false;
    }

    public List<Cliente> registrarMasivo(List<Cliente> clientes) {
        return clienteRepository.saveAll(clientes);
    }

}