package com.example.registrarcliente.config;

import com.example.registrarcliente.model.Cliente;
import com.example.registrarcliente.repository.ClienteRepository;
import net.datafaker.Faker;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Locale;

@Configuration
public class DataFakerConfig {

    @Bean
    public CommandLineRunner cargarDatosFalsos(ClienteRepository repository) {
        return args -> {
            // Verificamos si la tabla de clientes está vacía
            if (repository.count() == 0) {
                
                // Le decimos a Faker que genere datos en español
                Faker faker = new Faker(new Locale("es")); 
                
                System.out.println("Base de datos de clientes vacía. Generando 50 clientes de prueba...");

                for (int i = 0; i < 50; i++) {
                    Cliente cliente = new Cliente();
                    // Faker inventa los datos
                    cliente.setNombre(faker.name().fullName());
                    cliente.setCorreo(faker.internet().emailAddress());
                    
                    // Aseguramos que el teléfono no supere los caracteres de tu base de datos
                    String telefono = faker.phoneNumber().cellPhone();
                    if (telefono.length() > 15) {
                        telefono = telefono.substring(0, 15);
                    }
                    cliente.setTelefono(telefono);
                    
                    // Guardamos en la base de datos
                    repository.save(cliente);
                }
                
                System.out.println("¡50 clientes falsos generados y guardados con éxito!");
            } else {
                System.out.println("La base de datos ya tiene clientes. Omitiendo DataFaker.");
            }
        };
    }
}