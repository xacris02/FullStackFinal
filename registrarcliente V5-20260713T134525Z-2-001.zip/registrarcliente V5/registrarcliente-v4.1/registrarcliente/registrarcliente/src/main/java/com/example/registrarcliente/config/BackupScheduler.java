package com.example.registrarcliente.config;
import com.example.registrarcliente.service.BackupService;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.stereotype.Component;


@Component
@EnableScheduling 

public class BackupScheduler {

    private final BackupService backupService;

    public BackupScheduler(BackupService backupService) {
        this.backupService = backupService;
    }


    @Scheduled(cron = "0 0 2 * * ?")
    public void scheduleBackup() {
        backupService.createBackup();
    }
}